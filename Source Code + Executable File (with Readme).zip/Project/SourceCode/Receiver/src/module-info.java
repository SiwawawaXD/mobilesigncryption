module MobileSigncryptionReceiver3 {
	requires org.bouncycastle.provider;
	requires org.json;
	requires okio;           // OkHttp depends on Okio
    requires okhttp3;  
}